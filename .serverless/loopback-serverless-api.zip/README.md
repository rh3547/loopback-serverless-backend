# LoopBack 4 Lambda

npm i -g @loopback/cli
Re-running npm install --ignore-scripts and npm rebuild solved my problem

npm install -g serverless
